// ESI-based triage classification algorithm
// Based on the Emergency Severity Index (ESI) v4 triage framework

export interface PatientInput {
  age: number;
  gender: "male" | "female" | "other";
  chiefComplaint: string;
  heartRate: number;
  systolicBP: number;
  diastolicBP: number;
  respiratoryRate: number;
  temperature: number;
  oxygenSaturation: number;
  painLevel: number; // 0-10
  consciousness: "alert" | "verbal" | "pain" | "unresponsive";
  symptoms: string[];
}

export interface TriageResult {
  level: 1 | 2 | 3 | 4 | 5;
  label: string;
  color: string;
  textColor: string;
  borderColor: string;
  bgLight: string;
  responseTime: string;
  description: string;
  reasoning: string[];
  confidence: number;
  recommendations: string[];
  vitalsAssessment: {
    heartRate: { status: "normal" | "warning" | "critical"; note: string };
    bloodPressure: { status: "normal" | "warning" | "critical"; note: string };
    respiratoryRate: {
      status: "normal" | "warning" | "critical";
      note: string;
    };
    temperature: { status: "normal" | "warning" | "critical"; note: string };
    oxygenSaturation: {
      status: "normal" | "warning" | "critical";
      note: string;
    };
  };
}

const LEVEL_META = {
  1: {
    label: "Immediate",
    color: "bg-red-500",
    textColor: "text-red-400",
    borderColor: "border-red-500/30",
    bgLight: "bg-red-500/10",
    responseTime: "0 minutes",
    description:
      "Life-threatening condition requiring immediate intervention.",
  },
  2: {
    label: "Emergent",
    color: "bg-orange-500",
    textColor: "text-orange-400",
    borderColor: "border-orange-500/30",
    bgLight: "bg-orange-500/10",
    responseTime: "< 10 minutes",
    description:
      "High-risk situation with potential for rapid deterioration.",
  },
  3: {
    label: "Urgent",
    color: "bg-yellow-500",
    textColor: "text-yellow-400",
    borderColor: "border-yellow-500/30",
    bgLight: "bg-yellow-500/10",
    responseTime: "< 30 minutes",
    description:
      "Serious but stable condition requiring prompt medical attention.",
  },
  4: {
    label: "Less Urgent",
    color: "bg-green-500",
    textColor: "text-green-400",
    borderColor: "border-green-500/30",
    bgLight: "bg-green-500/10",
    responseTime: "< 60 minutes",
    description:
      "Condition not immediately dangerous but requiring evaluation.",
  },
  5: {
    label: "Non-Urgent",
    color: "bg-blue-500",
    textColor: "text-blue-400",
    borderColor: "border-blue-500/30",
    bgLight: "bg-blue-500/10",
    responseTime: "< 120 minutes",
    description:
      "Minor condition that could be handled in primary care settings.",
  },
};

// Critical keywords that immediately raise severity
const LEVEL1_KEYWORDS = [
  "cardiac arrest",
  "not breathing",
  "unresponsive",
  "severe hemorrhage",
  "anaphylaxis",
  "choking",
  "gunshot",
  "stab wound",
  "seizure active",
  "respiratory failure",
  "overdose",
  "cardiac",
  "arrest",
  "drowning",
];

const LEVEL2_KEYWORDS = [
  "chest pain",
  "stroke",
  "difficulty breathing",
  "severe bleeding",
  "head injury",
  "altered mental status",
  "high fever infant",
  "suicidal",
  "poisoning",
  "severe pain",
  "compound fracture",
  "severe burn",
  "allergic reaction",
  "slurred speech",
  "facial drooping",
  "numbness",
  "confusion",
];

const LEVEL3_KEYWORDS = [
  "abdominal pain",
  "fracture",
  "asthma",
  "moderate pain",
  "laceration",
  "dehydration",
  "vomiting blood",
  "diabetic",
  "high blood pressure",
  "infection",
  "kidney pain",
  "back pain severe",
];

const LEVEL4_KEYWORDS = [
  "minor laceration",
  "sprain",
  "ear infection",
  "urinary tract",
  "mild pain",
  "sore throat",
  "cough",
  "skin rash",
  "minor burn",
  "twisted ankle",
];

function assessVitals(input: PatientInput): TriageResult["vitalsAssessment"] {
  const isChild = input.age < 12;
  const isElderly = input.age > 65;

  // Heart rate
  let hrStatus: "normal" | "warning" | "critical" = "normal";
  let hrNote = "Within normal range";
  if (input.heartRate > 150 || input.heartRate < 40) {
    hrStatus = "critical";
    hrNote =
      input.heartRate > 150
        ? "Severe tachycardia"
        : "Severe bradycardia";
  } else if (
    input.heartRate > 120 ||
    input.heartRate < 50
  ) {
    hrStatus = "warning";
    hrNote =
      input.heartRate > 120 ? "Tachycardia detected" : "Bradycardia detected";
  }

  // Blood pressure
  let bpStatus: "normal" | "warning" | "critical" = "normal";
  let bpNote = "Within normal range";
  if (
    input.systolicBP > 180 ||
    input.systolicBP < 80 ||
    input.diastolicBP > 120
  ) {
    bpStatus = "critical";
    bpNote =
      input.systolicBP < 80
        ? "Hypotension - possible shock"
        : "Hypertensive crisis";
  } else if (
    input.systolicBP > 140 ||
    input.systolicBP < 90 ||
    input.diastolicBP > 90
  ) {
    bpStatus = "warning";
    bpNote =
      input.systolicBP < 90
        ? "Low blood pressure"
        : "Elevated blood pressure";
  }

  // Respiratory rate
  let rrStatus: "normal" | "warning" | "critical" = "normal";
  let rrNote = "Within normal range";
  const rrHigh = isChild ? 30 : 20;
  const rrCritHigh = isChild ? 40 : 30;
  if (input.respiratoryRate > rrCritHigh || input.respiratoryRate < 8) {
    rrStatus = "critical";
    rrNote =
      input.respiratoryRate < 8
        ? "Dangerously low respiratory rate"
        : "Severe tachypnea";
  } else if (input.respiratoryRate > rrHigh || input.respiratoryRate < 10) {
    rrStatus = "warning";
    rrNote =
      input.respiratoryRate < 10
        ? "Low respiratory rate"
        : "Elevated respiratory rate";
  }

  // Temperature
  let tempStatus: "normal" | "warning" | "critical" = "normal";
  let tempNote = "Within normal range";
  if (input.temperature >= 40 || input.temperature <= 34) {
    tempStatus = "critical";
    tempNote =
      input.temperature >= 40
        ? "Hyperthermia / severe fever"
        : "Hypothermia";
  } else if (input.temperature >= 38.5 || input.temperature <= 35.5) {
    tempStatus = "warning";
    tempNote =
      input.temperature >= 38.5
        ? `Fever detected (${input.temperature}${isChild || isElderly ? " - higher risk due to age" : ""})`
        : "Below normal temperature";
  }

  // Oxygen saturation
  let o2Status: "normal" | "warning" | "critical" = "normal";
  let o2Note = "Within normal range";
  if (input.oxygenSaturation < 90) {
    o2Status = "critical";
    o2Note = "Severe hypoxemia - immediate oxygen required";
  } else if (input.oxygenSaturation < 94) {
    o2Status = "warning";
    o2Note = "Low oxygen saturation - supplemental oxygen may be needed";
  }

  return {
    heartRate: { status: hrStatus, note: hrNote },
    bloodPressure: { status: bpStatus, note: bpNote },
    respiratoryRate: { status: rrStatus, note: rrNote },
    temperature: { status: tempStatus, note: tempNote },
    oxygenSaturation: { status: o2Status, note: o2Note },
  };
}

function matchKeywords(text: string, keywords: string[]): string[] {
  const lower = text.toLowerCase();
  return keywords.filter((kw) => lower.includes(kw));
}

export function classifyPatient(input: PatientInput): TriageResult {
  const reasoning: string[] = [];
  const recommendations: string[] = [];
  let score = 0; // Higher = more severe. We map: >=40 => L1, 25-39 => L2, 15-24 => L3, 8-14 => L4, <8 => L5

  const vitals = assessVitals(input);
  const allText = `${input.chiefComplaint} ${input.symptoms.join(" ")}`;

  // ---- Step 1: Consciousness check ----
  if (input.consciousness === "unresponsive") {
    score += 50;
    reasoning.push("Patient is unresponsive - immediate intervention required");
    recommendations.push("Initiate resuscitation protocol immediately");
  } else if (input.consciousness === "pain") {
    score += 30;
    reasoning.push("Patient responds only to pain stimuli");
    recommendations.push("Continuous neurological monitoring required");
  } else if (input.consciousness === "verbal") {
    score += 15;
    reasoning.push("Patient responds to verbal stimuli but not fully alert");
    recommendations.push("Monitor consciousness level closely");
  } else {
    reasoning.push("Patient is alert and oriented");
  }

  // ---- Step 2: Keyword analysis ----
  const l1Matches = matchKeywords(allText, LEVEL1_KEYWORDS);
  const l2Matches = matchKeywords(allText, LEVEL2_KEYWORDS);
  const l3Matches = matchKeywords(allText, LEVEL3_KEYWORDS);
  const l4Matches = matchKeywords(allText, LEVEL4_KEYWORDS);

  if (l1Matches.length > 0) {
    score += 40;
    reasoning.push(
      `Critical symptoms identified: ${l1Matches.join(", ")}`
    );
    recommendations.push("Activate emergency response team");
  }
  if (l2Matches.length > 0) {
    score += 20;
    reasoning.push(
      `High-risk symptoms identified: ${l2Matches.join(", ")}`
    );
    recommendations.push("Urgent physician evaluation required");
  }
  if (l3Matches.length > 0) {
    score += 10;
    reasoning.push(
      `Moderate symptoms identified: ${l3Matches.join(", ")}`
    );
    recommendations.push("Medical evaluation within 30 minutes");
  }
  if (l4Matches.length > 0) {
    score += 4;
    reasoning.push(
      `Minor symptoms identified: ${l4Matches.join(", ")}`
    );
  }

  // ---- Step 3: Vitals scoring ----
  const vitalEntries = Object.entries(vitals) as [
    string,
    { status: string; note: string },
  ][];
  let criticalVitals = 0;
  let warningVitals = 0;

  for (const [key, val] of vitalEntries) {
    if (val.status === "critical") {
      criticalVitals++;
      score += 15;
      reasoning.push(`Critical vital sign: ${formatVitalName(key)} - ${val.note}`);
    } else if (val.status === "warning") {
      warningVitals++;
      score += 6;
      reasoning.push(`Abnormal vital sign: ${formatVitalName(key)} - ${val.note}`);
    }
  }

  if (criticalVitals >= 2) {
    score += 10;
    recommendations.push("Multiple critical vitals - continuous monitoring essential");
  }
  if (warningVitals >= 3) {
    score += 5;
    recommendations.push("Multiple abnormal vitals - close observation required");
  }

  // ---- Step 4: Pain level ----
  if (input.painLevel >= 9) {
    score += 12;
    reasoning.push(`Severe pain reported (${input.painLevel}/10)`);
    recommendations.push("Immediate pain management required");
  } else if (input.painLevel >= 7) {
    score += 8;
    reasoning.push(`Significant pain reported (${input.painLevel}/10)`);
    recommendations.push("Pain assessment and management needed");
  } else if (input.painLevel >= 4) {
    score += 4;
    reasoning.push(`Moderate pain reported (${input.painLevel}/10)`);
  } else if (input.painLevel >= 1) {
    score += 1;
    reasoning.push(`Mild pain reported (${input.painLevel}/10)`);
  }

  // ---- Step 5: Age risk factors ----
  if (input.age < 2) {
    score += 8;
    reasoning.push("Infant patient - elevated risk due to age");
    recommendations.push("Pediatric specialist consultation recommended");
  } else if (input.age < 5) {
    score += 5;
    reasoning.push("Young child - age-related risk factor considered");
  } else if (input.age > 75) {
    score += 6;
    reasoning.push("Elderly patient - elevated risk due to age");
    recommendations.push("Comprehensive geriatric assessment recommended");
  } else if (input.age > 65) {
    score += 3;
    reasoning.push("Senior patient - age-related risk factor considered");
  }

  // ---- Determine ESI level ----
  let level: 1 | 2 | 3 | 4 | 5;
  if (score >= 40) {
    level = 1;
  } else if (score >= 25) {
    level = 2;
  } else if (score >= 15) {
    level = 3;
  } else if (score >= 8) {
    level = 4;
  } else {
    level = 5;
  }

  // Default recommendations
  if (recommendations.length === 0) {
    if (level <= 2) {
      recommendations.push("Immediate medical evaluation required");
    } else if (level === 3) {
      recommendations.push("Prompt medical evaluation recommended");
    } else if (level === 4) {
      recommendations.push("Standard medical evaluation");
    } else {
      recommendations.push("Routine evaluation - consider primary care referral");
    }
  }

  // Confidence based on data completeness and clarity
  const baseConfidence = 0.75;
  const keywordBoost = (l1Matches.length + l2Matches.length + l3Matches.length + l4Matches.length) > 0 ? 0.1 : 0;
  const vitalBoost = (criticalVitals + warningVitals) > 0 ? 0.08 : 0;
  const consciousnessBoost = input.consciousness !== "alert" ? 0.07 : 0;
  const confidence = Math.min(0.98, baseConfidence + keywordBoost + vitalBoost + consciousnessBoost);

  const meta = LEVEL_META[level];

  return {
    level,
    label: meta.label,
    color: meta.color,
    textColor: meta.textColor,
    borderColor: meta.borderColor,
    bgLight: meta.bgLight,
    responseTime: meta.responseTime,
    description: meta.description,
    reasoning,
    confidence,
    recommendations,
    vitalsAssessment: vitals,
  };
}

function formatVitalName(key: string): string {
  const map: Record<string, string> = {
    heartRate: "Heart Rate",
    bloodPressure: "Blood Pressure",
    respiratoryRate: "Respiratory Rate",
    temperature: "Temperature",
    oxygenSaturation: "Oxygen Saturation",
  };
  return map[key] ?? key;
}
