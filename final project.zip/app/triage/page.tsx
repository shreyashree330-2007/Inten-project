import type { Metadata } from "next";
import Link from "next/link";
import { Activity, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { TriageForm } from "@/components/triage-form";

export const metadata: Metadata = {
  title: "AI Triage Assessment | AI in Emergency Triage System",
  description:
    "Enter patient symptoms, vital signs, and clinical data to receive an AI-powered ESI triage classification.",
};

export default function TriagePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-lg">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
              <Activity className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="font-display text-lg font-bold text-foreground">
              TriageAI
            </span>
          </Link>

          <Button asChild variant="outline" size="sm" className="gap-2 bg-transparent">
            <Link href="/">
              <ArrowLeft className="h-3.5 w-3.5" />
              Back to Home
            </Link>
          </Button>
        </div>
      </header>

      {/* Page content */}
      <main className="px-6 py-12 lg:py-16">
        <div className="mx-auto max-w-3xl text-center">
          <div className="mb-2 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-sm text-primary">
            <Activity className="h-3.5 w-3.5" />
            <span>AI-Powered Classification</span>
          </div>
          <h1 className="font-display text-3xl font-bold text-foreground sm:text-4xl lg:text-5xl text-balance">
            Emergency Triage Assessment
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-lg leading-relaxed text-muted-foreground">
            Enter patient information, vital signs, and symptoms below. Our
            rule-based AI engine will classify the case into an ESI severity
            level with full reasoning.
          </p>
        </div>

        <div className="mt-12">
          <TriageForm />
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/50 px-6 py-6 text-center">
        <p className="text-xs text-muted-foreground">
          For demonstration and educational purposes only. Not a substitute for
          professional medical advice.
        </p>
      </footer>
    </div>
  );
}
