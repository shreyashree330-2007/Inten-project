import { Navbar } from "@/components/navbar";
import { HeroSection } from "@/components/hero-section";
import { ProblemSection } from "@/components/problem-section";
import { HowItWorksSection } from "@/components/how-it-works-section";
import { FeaturesSection } from "@/components/features-section";
import { TriageLevelsSection } from "@/components/triage-levels-section";
import { ImpactSection } from "@/components/impact-section";
import { TeamSection } from "@/components/team-section";
import { CtaSection } from "@/components/cta-section";
import { Footer } from "@/components/footer";

export default function Page() {
  return (
    <>
      <Navbar />
      <main>
        <HeroSection />
        <ProblemSection />
        <HowItWorksSection />
        <FeaturesSection />
        <TriageLevelsSection />
        <ImpactSection />
        <TeamSection />
        <CtaSection />
      </main>
      <Footer />
    </>
  );
}
