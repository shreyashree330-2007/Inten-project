import Image from "next/image";
import {
  Cpu,
  ShieldCheck,
  RefreshCw,
  BarChart3,
  Globe,
  Lock,
} from "lucide-react";

const features = [
  {
    icon: Cpu,
    title: "Machine Learning Engine",
    description:
      "Built on ensemble classification models including Random Forest and Gradient Boosting, trained on 50,000+ real-world triage records.",
  },
  {
    icon: ShieldCheck,
    title: "Clinical Validation",
    description:
      "Validated against Emergency Severity Index (ESI) standards with a 95% accuracy rate, peer-reviewed by emergency medicine professionals.",
  },
  {
    icon: RefreshCw,
    title: "Real-Time Re-Triage",
    description:
      "Continuously monitors patient vitals and automatically re-classifies severity if conditions change, ensuring dynamic and responsive care.",
  },
  {
    icon: BarChart3,
    title: "Analytics Dashboard",
    description:
      "Comprehensive visual analytics for hospital administrators showing patient flow, wait times, classification trends, and system performance.",
  },
  {
    icon: Globe,
    title: "Interoperable Design",
    description:
      "Seamlessly integrates with existing Electronic Health Record (EHR) systems through HL7 FHIR standards for hospital-wide adoption.",
  },
  {
    icon: Lock,
    title: "HIPAA Compliant",
    description:
      "All patient data is encrypted end-to-end with role-based access controls, ensuring full compliance with healthcare data privacy regulations.",
  },
];

export function FeaturesSection() {
  return (
    <section id="features" className="py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid items-center gap-16 lg:grid-cols-2">
          {/* Left — Features Grid */}
          <div>
            <p className="text-sm font-semibold uppercase tracking-widest text-primary">
              Key Features
            </p>
            <h2 className="font-display mt-3 text-3xl font-bold text-foreground sm:text-4xl text-balance">
              Built for Reliability, Designed for Speed
            </h2>
            <p className="mt-4 max-w-lg leading-relaxed text-muted-foreground">
              Every component of the system is engineered to handle the
              high-stakes demands of emergency medicine.
            </p>

            <div className="mt-10 grid gap-6 sm:grid-cols-2">
              {features.map((feature) => (
                <div key={feature.title} className="flex gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <feature.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-display text-sm font-semibold text-foreground">
                      {feature.title}
                    </h3>
                    <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                      {feature.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right — Image */}
          <div className="relative overflow-hidden rounded-2xl border border-border">
            <Image
              src="/images/system-architecture.jpg"
              alt="Neural network architecture visualization representing the AI triage system"
              width={700}
              height={500}
              className="w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent" />
          </div>
        </div>
      </div>
    </section>
  );
}
