import { AlertTriangle, Clock, Users } from "lucide-react";

const problems = [
  {
    icon: Clock,
    title: "Prolonged Wait Times",
    description:
      "Emergency departments worldwide face overcrowding, with patients waiting hours for initial assessment. Delays in triage can lead to deteriorating conditions and preventable fatalities.",
  },
  {
    icon: Users,
    title: "Subjective Human Assessment",
    description:
      "Traditional triage relies heavily on the experience and judgment of individual healthcare workers, leading to inconsistencies in how patients are classified and prioritized.",
  },
  {
    icon: AlertTriangle,
    title: "Resource Misallocation",
    description:
      "Without data-driven classification, critical resources like trauma bays and specialists may be allocated to lower-severity cases while high-risk patients remain untreated.",
  },
];

export function ProblemSection() {
  return (
    <section id="problem" className="py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary">
            The Challenge
          </p>
          <h2 className="font-display mt-3 text-3xl font-bold text-foreground sm:text-4xl text-balance">
            Emergency Triage Is Overwhelmed
          </h2>
          <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
            Every year, millions of patients visit emergency departments globally.
            Current systems struggle to keep pace with demand.
          </p>
        </div>

        <div className="mt-16 grid gap-8 md:grid-cols-3">
          {problems.map((problem) => (
            <div
              key={problem.title}
              className="group rounded-2xl border border-border bg-card p-8 transition-colors hover:border-primary/40"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                <problem.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-6 font-display text-xl font-semibold text-card-foreground">
                {problem.title}
              </h3>
              <p className="mt-3 leading-relaxed text-muted-foreground">
                {problem.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
