const levels = [
  {
    color: "bg-red-500",
    textColor: "text-red-400",
    borderColor: "border-red-500/30",
    bgLight: "bg-red-500/10",
    level: "Level 1",
    label: "Immediate",
    description:
      "Life-threatening conditions requiring immediate intervention. Examples include cardiac arrest, severe trauma, and respiratory failure.",
    examples: ["Cardiac Arrest", "Severe Hemorrhage", "Respiratory Failure"],
    responseTime: "0 minutes",
  },
  {
    color: "bg-orange-500",
    textColor: "text-orange-400",
    borderColor: "border-orange-500/30",
    bgLight: "bg-orange-500/10",
    level: "Level 2",
    label: "Emergent",
    description:
      "High-risk situations with potential for rapid deterioration. Conditions that could become life-threatening without timely treatment.",
    examples: ["Chest Pain", "Stroke Symptoms", "High Fever in Infants"],
    responseTime: "< 10 minutes",
  },
  {
    color: "bg-yellow-500",
    textColor: "text-yellow-400",
    borderColor: "border-yellow-500/30",
    bgLight: "bg-yellow-500/10",
    level: "Level 3",
    label: "Urgent",
    description:
      "Serious but stable conditions requiring prompt medical attention. Multiple resources may be needed for diagnosis and treatment.",
    examples: ["Abdominal Pain", "Fractures", "Moderate Asthma"],
    responseTime: "< 30 minutes",
  },
  {
    color: "bg-green-500",
    textColor: "text-green-400",
    borderColor: "border-green-500/30",
    bgLight: "bg-green-500/10",
    level: "Level 4",
    label: "Less Urgent",
    description:
      "Conditions that are not immediately dangerous but require medical evaluation. One resource typically needed.",
    examples: ["Minor Lacerations", "Sprains", "Ear Infections"],
    responseTime: "< 60 minutes",
  },
  {
    color: "bg-blue-500",
    textColor: "text-blue-400",
    borderColor: "border-blue-500/30",
    bgLight: "bg-blue-500/10",
    level: "Level 5",
    label: "Non-Urgent",
    description:
      "Minor conditions that could be handled in primary care settings. No resources expected beyond examination.",
    examples: ["Common Cold", "Minor Rash", "Prescription Refills"],
    responseTime: "< 120 minutes",
  },
];

export function TriageLevelsSection() {
  return (
    <section className="py-24 lg:py-32 bg-card">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary">
            Classification
          </p>
          <h2 className="font-display mt-3 text-3xl font-bold text-foreground sm:text-4xl text-balance">
            Emergency Severity Index (ESI) Levels
          </h2>
          <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
            Our AI classifies patients into five standardized severity levels,
            aligned with the globally recognized ESI framework.
          </p>
        </div>

        <div className="mt-16 grid gap-4 md:grid-cols-5">
          {levels.map((level) => (
            <div
              key={level.level}
              className={`rounded-2xl border ${level.borderColor} bg-background p-6 transition-all hover:scale-[1.02]`}
            >
              <div
                className={`inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-semibold ${level.bgLight} ${level.textColor}`}
              >
                <span className={`h-2 w-2 rounded-full ${level.color}`} />
                {level.level}
              </div>
              <h3
                className={`font-display mt-4 text-lg font-bold ${level.textColor}`}
              >
                {level.label}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {level.description}
              </p>
              <div className="mt-4 border-t border-border pt-4">
                <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Response Target
                </p>
                <p className={`mt-1 font-display text-sm font-bold ${level.textColor}`}>
                  {level.responseTime}
                </p>
              </div>
              <div className="mt-4">
                <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Examples
                </p>
                <ul className="mt-2 flex flex-col gap-1">
                  {level.examples.map((ex) => (
                    <li
                      key={ex}
                      className="text-xs text-muted-foreground"
                    >
                      {ex}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
