import { TrendingUp, HeartPulse, Timer, DollarSign } from "lucide-react";

const impacts = [
  {
    icon: HeartPulse,
    metric: "95.2%",
    label: "Triage Accuracy",
    description:
      "Our model achieves 95.2% accuracy in classifying patient severity levels, outperforming the average manual triage accuracy of 76%.",
  },
  {
    icon: Timer,
    metric: "< 8 sec",
    label: "Assessment Time",
    description:
      "Average time from data input to severity classification. Traditional manual triage takes 2-5 minutes per patient on average.",
  },
  {
    icon: TrendingUp,
    metric: "40%",
    label: "Reduced Wait Times",
    description:
      "Pilot studies show a 40% reduction in average emergency department wait times when AI-assisted triage is implemented.",
  },
  {
    icon: DollarSign,
    metric: "30%",
    label: "Cost Savings",
    description:
      "Hospitals report up to 30% reduction in operational costs through better resource allocation and reduced patient boarding time.",
  },
];

export function ImpactSection() {
  return (
    <section id="impact" className="py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary">
            Research & Impact
          </p>
          <h2 className="font-display mt-3 text-3xl font-bold text-foreground sm:text-4xl text-balance">
            Measurable Results, Real-World Impact
          </h2>
          <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
            Our system has been tested and validated in clinical environments,
            demonstrating significant improvements across all key metrics.
          </p>
        </div>

        <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {impacts.map((item) => (
            <div
              key={item.label}
              className="group rounded-2xl border border-border bg-card p-8 text-center transition-colors hover:border-primary/40"
            >
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                <item.icon className="h-7 w-7" />
              </div>
              <p className="mt-6 font-display text-4xl font-bold text-foreground">
                {item.metric}
              </p>
              <p className="mt-2 font-display text-sm font-semibold text-primary">
                {item.label}
              </p>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                {item.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
