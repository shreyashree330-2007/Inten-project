"use client";

import { useState } from "react";
import { Activity, ArrowRight, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { classifyPatient, type PatientInput, type TriageResult } from "@/lib/triage-algorithm";
import { TriageResultDisplay } from "@/components/triage-result";

const SYMPTOM_OPTIONS = [
  "Chest pain",
  "Difficulty breathing",
  "Severe bleeding",
  "Head injury",
  "Abdominal pain",
  "Fracture",
  "Fever",
  "Vomiting",
  "Dizziness",
  "Confusion",
  "Seizure",
  "Allergic reaction",
  "Stroke symptoms",
  "Severe burn",
  "Back pain",
  "Cough",
  "Sore throat",
  "Minor laceration",
  "Sprain",
  "Skin rash",
  "Ear infection",
  "Numbness",
  "Fainting",
  "Poisoning",
  "Dehydration",
];

export function TriageForm() {
  const [result, setResult] = useState<TriageResult | null>(null);
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);

  // Form state
  const [age, setAge] = useState("");
  const [gender, setGender] = useState<"male" | "female" | "other">("male");
  const [chiefComplaint, setChiefComplaint] = useState("");
  const [heartRate, setHeartRate] = useState("");
  const [systolicBP, setSystolicBP] = useState("");
  const [diastolicBP, setDiastolicBP] = useState("");
  const [respiratoryRate, setRespiratoryRate] = useState("");
  const [temperature, setTemperature] = useState("");
  const [oxygenSaturation, setOxygenSaturation] = useState("");
  const [painLevel, setPainLevel] = useState([3]);
  const [consciousness, setConsciousness] = useState<
    "alert" | "verbal" | "pain" | "unresponsive"
  >("alert");

  function toggleSymptom(symptom: string) {
    setSelectedSymptoms((prev) =>
      prev.includes(symptom)
        ? prev.filter((s) => s !== symptom)
        : [...prev, symptom]
    );
  }

  function handleSubmit() {
    const input: PatientInput = {
      age: Number(age) || 30,
      gender,
      chiefComplaint,
      heartRate: Number(heartRate) || 80,
      systolicBP: Number(systolicBP) || 120,
      diastolicBP: Number(diastolicBP) || 80,
      respiratoryRate: Number(respiratoryRate) || 16,
      temperature: Number(temperature) || 37,
      oxygenSaturation: Number(oxygenSaturation) || 98,
      painLevel: painLevel[0],
      consciousness,
      symptoms: selectedSymptoms,
    };
    const triageResult = classifyPatient(input);
    setResult(triageResult);
  }

  function handleReset() {
    setResult(null);
    setStep(1);
    setAge("");
    setGender("male");
    setChiefComplaint("");
    setHeartRate("");
    setSystolicBP("");
    setDiastolicBP("");
    setRespiratoryRate("");
    setTemperature("");
    setOxygenSaturation("");
    setPainLevel([3]);
    setConsciousness("alert");
    setSelectedSymptoms([]);
  }

  if (result) {
    return <TriageResultDisplay result={result} onReset={handleReset} />;
  }

  return (
    <div className="mx-auto max-w-3xl">
      {/* Step indicator */}
      <div className="mb-10 flex items-center justify-center gap-3">
        {[1, 2, 3].map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => setStep(s as 1 | 2 | 3)}
            className="flex items-center gap-2"
          >
            <div
              className={`flex h-9 w-9 items-center justify-center rounded-full text-sm font-bold transition-colors ${
                s === step
                  ? "bg-primary text-primary-foreground"
                  : s < step
                    ? "bg-primary/20 text-primary"
                    : "bg-secondary text-muted-foreground"
              }`}
            >
              {s}
            </div>
            <span
              className={`hidden text-sm font-medium sm:inline ${
                s === step ? "text-foreground" : "text-muted-foreground"
              }`}
            >
              {s === 1
                ? "Patient Info"
                : s === 2
                  ? "Vital Signs"
                  : "Symptoms"}
            </span>
            {s < 3 && (
              <div className="mx-2 hidden h-px w-8 bg-border sm:block" />
            )}
          </button>
        ))}
      </div>

      {/* Step 1: Patient Information */}
      {step === 1 && (
        <div className="space-y-6">
          <div className="rounded-2xl border border-border bg-card p-6 lg:p-8">
            <h3 className="font-display text-xl font-bold text-foreground">
              Patient Information
            </h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Enter the basic demographics of the patient.
            </p>

            <div className="mt-6 grid gap-6 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="age" className="text-foreground">Age</Label>
                <Input
                  id="age"
                  type="number"
                  placeholder="e.g. 45"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  className="bg-secondary border-border text-foreground placeholder:text-muted-foreground"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="gender" className="text-foreground">Gender</Label>
                <Select value={gender} onValueChange={(v) => setGender(v as "male" | "female" | "other")}>
                  <SelectTrigger id="gender" className="bg-secondary border-border text-foreground">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="mt-6 space-y-2">
              <Label htmlFor="chief-complaint" className="text-foreground">
                Chief Complaint
              </Label>
              <Input
                id="chief-complaint"
                placeholder="Describe the primary reason for visit, e.g. 'chest pain and difficulty breathing'"
                value={chiefComplaint}
                onChange={(e) => setChiefComplaint(e.target.value)}
                className="bg-secondary border-border text-foreground placeholder:text-muted-foreground"
              />
              <p className="text-xs text-muted-foreground">
                Be as specific as possible. This helps the AI classify severity accurately.
              </p>
            </div>

            <div className="mt-6 space-y-3">
              <Label className="text-foreground">
                Consciousness Level (AVPU Scale)
              </Label>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                {(
                  [
                    { value: "alert", label: "Alert", desc: "Fully conscious" },
                    { value: "verbal", label: "Verbal", desc: "Responds to voice" },
                    { value: "pain", label: "Pain", desc: "Responds to pain" },
                    { value: "unresponsive", label: "Unresponsive", desc: "No response" },
                  ] as const
                ).map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => setConsciousness(option.value)}
                    className={`rounded-xl border p-3 text-left transition-all ${
                      consciousness === option.value
                        ? "border-primary bg-primary/10"
                        : "border-border bg-secondary hover:border-muted-foreground/30"
                    }`}
                  >
                    <p
                      className={`text-sm font-semibold ${
                        consciousness === option.value
                          ? "text-primary"
                          : "text-foreground"
                      }`}
                    >
                      {option.label}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {option.desc}
                    </p>
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="flex justify-end">
            <Button onClick={() => setStep(2)} className="gap-2">
              Next: Vital Signs
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Step 2: Vital Signs */}
      {step === 2 && (
        <div className="space-y-6">
          <div className="rounded-2xl border border-border bg-card p-6 lg:p-8">
            <h3 className="font-display text-xl font-bold text-foreground">
              Vital Signs
            </h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Enter the patient{"'"}s current vital sign readings.
            </p>

            <div className="mt-6 grid gap-6 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="heart-rate" className="text-foreground">
                  Heart Rate (bpm)
                </Label>
                <Input
                  id="heart-rate"
                  type="number"
                  placeholder="e.g. 80"
                  value={heartRate}
                  onChange={(e) => setHeartRate(e.target.value)}
                  className="bg-secondary border-border text-foreground placeholder:text-muted-foreground"
                />
                <p className="text-xs text-muted-foreground">
                  Normal: 60-100 bpm
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="respiratory-rate" className="text-foreground">
                  Respiratory Rate (breaths/min)
                </Label>
                <Input
                  id="respiratory-rate"
                  type="number"
                  placeholder="e.g. 16"
                  value={respiratoryRate}
                  onChange={(e) => setRespiratoryRate(e.target.value)}
                  className="bg-secondary border-border text-foreground placeholder:text-muted-foreground"
                />
                <p className="text-xs text-muted-foreground">
                  Normal: 12-20 breaths/min
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="systolic-bp" className="text-foreground">
                  Systolic BP (mmHg)
                </Label>
                <Input
                  id="systolic-bp"
                  type="number"
                  placeholder="e.g. 120"
                  value={systolicBP}
                  onChange={(e) => setSystolicBP(e.target.value)}
                  className="bg-secondary border-border text-foreground placeholder:text-muted-foreground"
                />
                <p className="text-xs text-muted-foreground">
                  Normal: 90-140 mmHg
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="diastolic-bp" className="text-foreground">
                  Diastolic BP (mmHg)
                </Label>
                <Input
                  id="diastolic-bp"
                  type="number"
                  placeholder="e.g. 80"
                  value={diastolicBP}
                  onChange={(e) => setDiastolicBP(e.target.value)}
                  className="bg-secondary border-border text-foreground placeholder:text-muted-foreground"
                />
                <p className="text-xs text-muted-foreground">
                  Normal: 60-90 mmHg
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="temperature" className="text-foreground">
                  Temperature (C)
                </Label>
                <Input
                  id="temperature"
                  type="number"
                  step="0.1"
                  placeholder="e.g. 37.0"
                  value={temperature}
                  onChange={(e) => setTemperature(e.target.value)}
                  className="bg-secondary border-border text-foreground placeholder:text-muted-foreground"
                />
                <p className="text-xs text-muted-foreground">
                  Normal: 36.1-37.2 C
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="oxygen" className="text-foreground">
                  Oxygen Saturation (%)
                </Label>
                <Input
                  id="oxygen"
                  type="number"
                  placeholder="e.g. 98"
                  value={oxygenSaturation}
                  onChange={(e) => setOxygenSaturation(e.target.value)}
                  className="bg-secondary border-border text-foreground placeholder:text-muted-foreground"
                />
                <p className="text-xs text-muted-foreground">
                  Normal: 95-100%
                </p>
              </div>
            </div>

            {/* Pain scale */}
            <div className="mt-8 space-y-3">
              <Label className="text-foreground">
                Pain Level: <span className="text-primary font-bold">{painLevel[0]}/10</span>
              </Label>
              <Slider
                value={painLevel}
                onValueChange={setPainLevel}
                min={0}
                max={10}
                step={1}
                className="py-2"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>No pain</span>
                <span>Mild</span>
                <span>Moderate</span>
                <span>Severe</span>
                <span>Worst</span>
              </div>
            </div>
          </div>

          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => setStep(1)}
              className="gap-2 bg-transparent"
            >
              Back
            </Button>
            <Button onClick={() => setStep(3)} className="gap-2">
              Next: Symptoms
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Step 3: Symptoms */}
      {step === 3 && (
        <div className="space-y-6">
          <div className="rounded-2xl border border-border bg-card p-6 lg:p-8">
            <h3 className="font-display text-xl font-bold text-foreground">
              Symptoms
            </h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Select all symptoms that apply to the patient.
            </p>

            <div className="mt-6 flex flex-wrap gap-2">
              {SYMPTOM_OPTIONS.map((symptom) => (
                <button
                  key={symptom}
                  type="button"
                  onClick={() => toggleSymptom(symptom)}
                  className={`rounded-full border px-3.5 py-1.5 text-sm transition-all ${
                    selectedSymptoms.includes(symptom)
                      ? "border-primary bg-primary/15 text-primary font-medium"
                      : "border-border bg-secondary text-muted-foreground hover:border-muted-foreground/40 hover:text-foreground"
                  }`}
                >
                  {symptom}
                </button>
              ))}
            </div>

            {selectedSymptoms.length > 0 && (
              <div className="mt-6 rounded-xl border border-border bg-secondary/50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Selected Symptoms
                </p>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {selectedSymptoms.map((s) => (
                    <Badge
                      key={s}
                      variant="secondary"
                      className="cursor-pointer bg-primary/15 text-primary border-primary/30 hover:bg-primary/25"
                      onClick={() => toggleSymptom(s)}
                    >
                      {s} &times;
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Summary before submit */}
          <div className="rounded-2xl border border-primary/20 bg-primary/5 p-6">
            <div className="flex items-start gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/15">
                <Activity className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h4 className="font-display font-bold text-foreground">
                  Ready to Classify
                </h4>
                <p className="mt-1 text-sm text-muted-foreground">
                  The AI will analyze all inputs, including patient demographics,
                  vital signs, consciousness level, symptoms, and pain level to
                  determine the ESI triage classification.
                </p>
              </div>
            </div>
          </div>

          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => setStep(2)}
              className="gap-2 bg-transparent"
            >
              Back
            </Button>
            <Button onClick={handleSubmit} size="lg" className="gap-2 text-base">
              <Activity className="h-4 w-4" />
              Run AI Triage Classification
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
