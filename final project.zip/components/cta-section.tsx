import Link from "next/link";
import { ArrowRight, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";

export function CtaSection() {
  return (
    <section id="contact" className="py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <div className="relative overflow-hidden rounded-3xl border border-primary/20 bg-primary/5 p-12 text-center lg:p-20">
          {/* Decorative border glow */}
          <div className="absolute -top-px left-1/4 right-1/4 h-px bg-gradient-to-r from-transparent via-primary/60 to-transparent" />

          <div className="mx-auto max-w-2xl">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-sm text-primary">
              <Mail className="h-3.5 w-3.5" />
              <span>Get In Touch</span>
            </div>

            <h2 className="font-display text-3xl font-bold text-foreground sm:text-4xl text-balance">
              Interested in Our Research?
            </h2>
            <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
              Whether you are a healthcare institution exploring AI-assisted
              triage, a researcher interested in collaboration, or an academic
              evaluator reviewing our project — we would love to hear from you.
            </p>

            <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Button size="lg" className="gap-2 text-base">
                <Mail className="h-4 w-4" />
                Contact the Team
              </Button>
              <Button size="lg" variant="outline" asChild className="gap-2 text-base bg-transparent">
                <Link href="#features">
                  Learn More
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
