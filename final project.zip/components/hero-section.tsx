import Link from "next/link";
import Image from "next/image";
import { ArrowRight, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

export function HeroSection() {
  return (
    <section className="relative flex min-h-screen items-center overflow-hidden pt-20">
      {/* Background image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/hero-triage.jpg"
          alt="Emergency room with AI technology"
          fill
          className="object-cover opacity-30"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/80 to-background" />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-6 py-24 lg:py-32">
        <div className="mx-auto max-w-3xl text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-sm text-primary">
            <Zap className="h-3.5 w-3.5" />
            <span>AI-Powered Emergency Healthcare</span>
          </div>

          <h1 className="font-display text-4xl font-bold leading-tight tracking-tight text-foreground sm:text-5xl lg:text-7xl text-balance">
            Smarter Triage.{" "}
            <span className="text-primary">Faster Response.</span>{" "}
            Saved Lives.
          </h1>

          <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-muted-foreground lg:text-xl">
            Our AI-driven triage system analyzes patient symptoms in real time,
            classifying emergency severity with precision to ensure critical
            patients receive care first.
          </p>

          <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Button size="lg" asChild className="gap-2 text-base">
              <Link href="/triage">
                Try the Triage Tool
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              asChild
              className="gap-2 text-base bg-transparent"
            >
              <Link href="#how-it-works">Explore the System</Link>
            </Button>
          </div>

          {/* Stats row */}
          <div className="mt-16 grid grid-cols-3 gap-8 border-t border-border/50 pt-10">
            <div>
              <p className="font-display text-3xl font-bold text-primary lg:text-4xl">
                95%
              </p>
              <p className="mt-1 text-sm text-muted-foreground">
                Classification Accuracy
              </p>
            </div>
            <div>
              <p className="font-display text-3xl font-bold text-primary lg:text-4xl">
                3x
              </p>
              <p className="mt-1 text-sm text-muted-foreground">
                Faster Than Manual
              </p>
            </div>
            <div>
              <p className="font-display text-3xl font-bold text-primary lg:text-4xl">
                40%
              </p>
              <p className="mt-1 text-sm text-muted-foreground">
                Reduced Wait Times
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
