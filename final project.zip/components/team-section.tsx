import { User } from "lucide-react";

const team = [
  {
    name: "Team Member 1",
    role: "Project Lead / ML Engineer",
    description:
      "Responsible for model architecture design, training pipeline, and overall project coordination.",
  },
  {
    name: "Team Member 2",
    role: "Data Scientist",
    description:
      "Handles data preprocessing, feature engineering, and statistical analysis of triage datasets.",
  },
  {
    name: "Team Member 3",
    role: "Full-Stack Developer",
    description:
      "Builds the web application, dashboard interface, and API integration with hospital systems.",
  },
  {
    name: "Team Member 4",
    role: "Research Analyst",
    description:
      "Conducts literature review, clinical validation studies, and documentation of research findings.",
  },
];

export function TeamSection() {
  return (
    <section id="team" className="py-24 lg:py-32 bg-card">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary">
            Our Team
          </p>
          <h2 className="font-display mt-3 text-3xl font-bold text-foreground sm:text-4xl text-balance">
            The Minds Behind TriageAI
          </h2>
          <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
            A multidisciplinary team combining expertise in artificial
            intelligence, emergency medicine, and software engineering.
          </p>
        </div>

        <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {team.map((member) => (
            <div
              key={member.name}
              className="group rounded-2xl border border-border bg-background p-8 text-center transition-colors hover:border-primary/40"
            >
              <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-colors group-hover:bg-primary/10 group-hover:text-primary">
                <User className="h-8 w-8" />
              </div>
              <h3 className="mt-6 font-display text-lg font-semibold text-foreground">
                {member.name}
              </h3>
              <p className="mt-1 text-sm font-medium text-primary">
                {member.role}
              </p>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                {member.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
