"use client";

import React from "react"

import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Heart,
  RotateCcw,
  ShieldCheck,
  Thermometer,
  Wind,
  Droplets,
  Brain,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import type { TriageResult } from "@/lib/triage-algorithm";

function StatusIcon({ status }: { status: "normal" | "warning" | "critical" }) {
  if (status === "critical") {
    return <AlertTriangle className="h-4 w-4 text-red-400" />;
  }
  if (status === "warning") {
    return <AlertTriangle className="h-4 w-4 text-yellow-400" />;
  }
  return <CheckCircle2 className="h-4 w-4 text-green-400" />;
}

function statusBg(status: "normal" | "warning" | "critical") {
  if (status === "critical") return "border-red-500/30 bg-red-500/5";
  if (status === "warning") return "border-yellow-500/30 bg-yellow-500/5";
  return "border-green-500/30 bg-green-500/5";
}

const VITAL_ICONS: Record<string, React.ReactNode> = {
  heartRate: <Heart className="h-4 w-4" />,
  bloodPressure: <Droplets className="h-4 w-4" />,
  respiratoryRate: <Wind className="h-4 w-4" />,
  temperature: <Thermometer className="h-4 w-4" />,
  oxygenSaturation: <Activity className="h-4 w-4" />,
};

const VITAL_LABELS: Record<string, string> = {
  heartRate: "Heart Rate",
  bloodPressure: "Blood Pressure",
  respiratoryRate: "Respiratory Rate",
  temperature: "Temperature",
  oxygenSaturation: "Oxygen Saturation",
};

export function TriageResultDisplay({
  result,
  onReset,
}: {
  result: TriageResult;
  onReset: () => void;
}) {
  return (
    <div className="mx-auto max-w-3xl space-y-6">
      {/* Main result card */}
      <div
        className={`rounded-2xl border ${result.borderColor} overflow-hidden`}
      >
        {/* Header band */}
        <div className={`${result.bgLight} px-6 py-8 lg:px-8 lg:py-10`}>
          <div className="flex flex-col items-center text-center">
            <div
              className={`flex h-16 w-16 items-center justify-center rounded-2xl ${result.color}`}
            >
              <ShieldCheck className="h-8 w-8 text-background" />
            </div>
            <p
              className={`mt-4 text-sm font-semibold uppercase tracking-widest ${result.textColor}`}
            >
              ESI {result.level === 1 ? "Level 1" : result.level === 2 ? "Level 2" : result.level === 3 ? "Level 3" : result.level === 4 ? "Level 4" : "Level 5"}
            </p>
            <h2
              className={`font-display mt-2 text-4xl font-bold ${result.textColor}`}
            >
              {result.label}
            </h2>
            <p className="mt-2 max-w-md text-sm text-muted-foreground">
              {result.description}
            </p>

            <div className="mt-6 flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Clock className={`h-4 w-4 ${result.textColor}`} />
                <span className="text-sm text-foreground">
                  Response: <span className="font-bold">{result.responseTime}</span>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Brain className={`h-4 w-4 ${result.textColor}`} />
                <span className="text-sm text-foreground">
                  Confidence:{" "}
                  <span className="font-bold">
                    {Math.round(result.confidence * 100)}%
                  </span>
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Confidence bar */}
        <div className="border-t border-border bg-card px-6 py-4 lg:px-8">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>AI Confidence Score</span>
            <span className="font-bold text-foreground">
              {Math.round(result.confidence * 100)}%
            </span>
          </div>
          <Progress
            value={result.confidence * 100}
            className="mt-2 h-2 bg-secondary"
          />
        </div>
      </div>

      {/* Vitals assessment */}
      <div className="rounded-2xl border border-border bg-card p-6 lg:p-8">
        <h3 className="font-display text-lg font-bold text-foreground">
          Vitals Assessment
        </h3>
        <p className="mt-1 text-sm text-muted-foreground">
          Individual vital sign analysis based on clinical parameters.
        </p>

        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {Object.entries(result.vitalsAssessment).map(([key, val]) => (
            <div
              key={key}
              className={`rounded-xl border p-4 ${statusBg(val.status)}`}
            >
              <div className="flex items-center gap-2">
                <span className="text-muted-foreground">
                  {VITAL_ICONS[key]}
                </span>
                <span className="text-sm font-semibold text-foreground">
                  {VITAL_LABELS[key]}
                </span>
              </div>
              <div className="mt-2 flex items-center gap-1.5">
                <StatusIcon status={val.status} />
                <span className="text-xs text-muted-foreground">
                  {val.note}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* AI Reasoning */}
      <div className="rounded-2xl border border-border bg-card p-6 lg:p-8">
        <h3 className="font-display text-lg font-bold text-foreground">
          AI Reasoning
        </h3>
        <p className="mt-1 text-sm text-muted-foreground">
          Key factors that contributed to this classification.
        </p>

        <ul className="mt-5 space-y-3">
          {result.reasoning.map((reason, i) => (
            <li key={i} className="flex items-start gap-3">
              <span className="mt-1 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/15 text-xs font-bold text-primary">
                {i + 1}
              </span>
              <span className="text-sm text-muted-foreground">{reason}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Recommendations */}
      <div className="rounded-2xl border border-primary/20 bg-primary/5 p-6 lg:p-8">
        <h3 className="font-display text-lg font-bold text-foreground">
          Recommendations
        </h3>
        <p className="mt-1 text-sm text-muted-foreground">
          Suggested next steps based on the triage classification.
        </p>

        <ul className="mt-5 space-y-2">
          {result.recommendations.map((rec, i) => (
            <li key={i} className="flex items-start gap-2">
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              <span className="text-sm text-foreground">{rec}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Disclaimer */}
      <div className="rounded-xl border border-yellow-500/20 bg-yellow-500/5 p-4">
        <div className="flex items-start gap-2">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-yellow-400" />
          <p className="text-xs leading-relaxed text-yellow-200/80">
            <span className="font-semibold">Disclaimer:</span> This AI triage
            classification is for demonstration and educational purposes only.
            It should not replace professional medical judgment. Always consult
            qualified healthcare providers for actual medical decisions.
          </p>
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
        <Button onClick={onReset} variant="outline" className="gap-2 bg-transparent">
          <RotateCcw className="h-4 w-4" />
          New Assessment
        </Button>
        <Button
          onClick={() => {
            if (typeof window !== "undefined") {
              window.print();
            }
          }}
          className="gap-2"
        >
          Print Report
        </Button>
      </div>
    </div>
  );
}
