import Image from "next/image";
import { ClipboardList, Brain, ListChecks, BellRing } from "lucide-react";

const steps = [
  {
    number: "01",
    icon: ClipboardList,
    title: "Data Collection",
    description:
      "Patient vitals, symptoms, medical history, and chief complaints are captured through electronic health records or intake forms upon arrival at the emergency department.",
  },
  {
    number: "02",
    icon: Brain,
    title: "AI Analysis",
    description:
      "Our machine learning model — trained on thousands of historical triage cases — processes patient data in real time, identifying patterns and risk indicators invisible to the human eye.",
  },
  {
    number: "03",
    icon: ListChecks,
    title: "Severity Classification",
    description:
      "The system assigns an Emergency Severity Index (ESI) level, color-coded for instant recognition: Red (Immediate), Yellow (Urgent), and Green (Non-Urgent).",
  },
  {
    number: "04",
    icon: BellRing,
    title: "Alert & Prioritize",
    description:
      "Healthcare teams receive instant notifications with prioritized patient queues, recommended interventions, and dynamic re-triage alerts as patient conditions change.",
  },
];

export function HowItWorksSection() {
  return (
    <section id="how-it-works" className="py-24 lg:py-32 bg-card">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid items-center gap-16 lg:grid-cols-2">
          {/* Left — Image */}
          <div className="relative overflow-hidden rounded-2xl border border-border">
            <Image
              src="/images/ai-analysis.jpg"
              alt="AI-powered triage analysis dashboard showing patient severity classification"
              width={700}
              height={500}
              className="w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-card/60 to-transparent" />
          </div>

          {/* Right — Steps */}
          <div>
            <p className="text-sm font-semibold uppercase tracking-widest text-primary">
              How It Works
            </p>
            <h2 className="font-display mt-3 text-3xl font-bold text-foreground sm:text-4xl text-balance">
              From Symptoms to Severity in Seconds
            </h2>

            <div className="mt-10 flex flex-col gap-8">
              {steps.map((step) => (
                <div key={step.number} className="flex gap-5">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-primary/30 bg-primary/10 font-display text-sm font-bold text-primary">
                    {step.number}
                  </div>
                  <div>
                    <h3 className="font-display text-lg font-semibold text-foreground">
                      {step.title}
                    </h3>
                    <p className="mt-1.5 leading-relaxed text-muted-foreground">
                      {step.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
